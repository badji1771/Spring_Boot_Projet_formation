package org.formation.hibernate.client;

public class TestClientPersist3 {

	public static void main(String[] args) {



	}

}
